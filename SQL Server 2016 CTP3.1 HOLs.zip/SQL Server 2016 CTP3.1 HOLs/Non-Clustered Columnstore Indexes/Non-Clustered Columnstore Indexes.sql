-- If you haven't already set your current database, run these 2 lines
USE AdventureworksDW2016CTP3
GO

--Comparing performance with a nonclustered Columnstore index

-- 1 Create a non-clustered columnstore index on a table that already has a clustered index on it. 
CREATE NONCLUSTERED COLUMNSTORE INDEX [Idx_Columnstore] 
ON [dbo].[FactResellerSalesXL_PageCompressed]
(
	[ShipDateKey],
	[SalesTerritoryKey],
	[ProductKey],
	[SalesAmount]
)WITH (DROP_EXISTING = OFF) ON [PRIMARY]
GO

-- 2 Run a query, but ignore the index
DBCC DROPCLEANBUFFERS
GO
SET STATISTICS TIME ON
SET STATISTICS IO ON
SELECT AVG(SalesAmount) AS AvgSales, SUM(SalesAmount) AS TotalSales
FROM FactResellerSalesXL_PageCompressed
WHERE ShipDateKey BETWEEN 20080101 AND 20100101
GROUP BY SalesTerritoryKey, ProductKey
OPTION (IGNORE_NONCLUSTERED_COLUMNSTORE_INDEX) --this ignores the index
GO

-- 4 Run the query again, this time with the index
DBCC DROPCLEANBUFFERS
GO
SET STATISTICS TIME ON
SET STATISTICS IO ON
SELECT AVG(SalesAmount) AS AvgSales, SUM(SalesAmount) AS TotalSales
FROM FactResellerSalesXL_PageCompressed
WHERE ShipDateKey BETWEEN 20080101 AND 20100101
GROUP BY SalesTerritoryKey, ProductKey
GO

-- Inserting data to a table with a non-clustered Columnstore index
SET STATISTICS TIME OFF
SET STATISTICS IO OFF
INSERT  
	INTO FactResellerSalesXL_PageCompressed
		(ProductKey, OrderDateKey, DueDateKey,
		ShipDateKey, ResellerKey, EmployeeKey, PromotionKey, CurrencyKey, SalesTerritoryKey,
		SalesOrderNumber, SalesOrderLineNumber, OrderQuantity, UnitPrice, SalesAmount, TaxAmt)
	SELECT TOP 2000 ProductKey, OrderDateKey, DueDateKey, 20140101, ResellerKey,
		EmployeeKey, PromotionKey, CurrencyKey, SalesTerritoryKey, SalesOrderNumber+'T', 
		SalesOrderLineNumber, OrderQuantity, UnitPrice, SalesAmount, TaxAmt
	FROM FactResellerSalesXL_CCI
	WHERE ShipDateKey BETWEEN 20121205 AND 20140101;




