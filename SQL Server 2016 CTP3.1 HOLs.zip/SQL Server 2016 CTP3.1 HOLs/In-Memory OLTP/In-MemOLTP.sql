-- Lab 2
-- 2.1 Create new natively compiled stored proc
USE AdventureWorks2016CTP3
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('Sales.[usp_GenerateReceipt_inmem]') IS NOT NULL
DROP PROCEDURE [Sales].[usp_GenerateReceipt_inmem]
GO
CREATE PROCEDURE [Sales].[usp_GenerateReceipt_inmem]
	@SalesOrderID int 
WITH NATIVE_COMPILATION, SCHEMABINDING 
AS
BEGIN ATOMIC WITH
  (TRANSACTION ISOLATION LEVEL = SNAPSHOT,
   LANGUAGE = N'us_english')
   	DECLARE @totalweight FLOAT
	SELECT  @totalweight = SUM(ISNULL(weight,0) * OrderQty )
	FROM Sales.SalesOrderDetail_inmem a
	INNER JOIN Production.Product_inmem b ON a.ProductID = b.ProductID
	WHERE a.SalesOrderID = @SalesOrderID

	SELECT SalesOrderID,OrderDate,ShipDate,SubTotal,TaxAmt, 
	@totalweight AS TotalWeight
	FROM Sales.SalesOrderHeader_inmem
	WHERE SalesOrderID = @SalesOrderID
	-- UNION ALL now allowed (not available in  SQL Server 14)
	-- Left outer join now allowed (not available in  SQL Serve  14)
	SELECT b.Name,b.ProductNumber,Color,a.OrderQty, '' AS Discountpct, UnitPrice
	FROM Sales.SalesOrderDetail_inmem a
	INNER JOIN Production.Product_inmem b ON a.ProductID = b.ProductID
	WHERE SalesOrderID = @SalesOrderID
	AND a.SpecialOfferID  = 1
	UNION ALL
	SELECT b.Name,b.ProductNumber,Color,a.OrderQty,
	 c.Description + ' -- ' + CAST(Discountpct*100 AS VARCHAR(10)) + '%' AS Discountpct,
	 UnitPrice
	FROM Sales.SalesOrderDetail_inmem a
	INNER JOIN Production.Product_inmem b ON a.ProductID = b.ProductID
	LEFT OUTER JOIN Sales.SpecialOffer_inmem c ON a.SpecialOfferID = c.SpecialOfferID
	LEFT OUTER JOIN Sales.SpecialOfferProduct_inmem d ON d.ProductID=b.ProductID
	AND c.SpecialOfferID = d.SpecialOfferID
	WHERE SalesOrderID = @SalesOrderID
	AND a.SpecialOfferID  <> 1
	END
GO

-- Lab 3
-- Explore new ALTER capabilities in SQL vNext
-- index operations

-- 3.1 Change hash index bucket count
ALTER TABLE Sales.SalesOrderDetail_inmem 
	ALTER INDEX imPK_SalesOrderDetail_SalesOrderID_SalesOrderDetailID
		REBUILD WITH (BUCKET_COUNT=100000000)
GO

-- verify new bucket count
SELECT index_id, name, bucket_count
FROM sys.hash_indexes 
WHERE object_id=object_id('Sales.SalesOrderDetail_inmem')
GO

-- add index
ALTER TABLE Sales.SalesOrderDetail_inmem 
	ADD INDEX IX_ModifiedDate NONCLUSTERED (ModifiedDate)
GO

-- verify new index
SELECT index_id, name, type_desc
FROM sys.indexes 
WHERE object_id=object_id('Sales.SalesOrderDetail_inmem')
GO

-- add column operations

-- 3.2 Verify memory utilization for Sales.SpecialOfferProduct_inmem
--   notice that there is one memory consumer for the table data, 
--   and one consumer each for the indexes
SELECT object_name(object_id), 
	object_id,
	xtp_object_id,
	memory_consumer_type_desc,
	memory_consumer_desc,
	allocated_bytes,
	used_bytes
FROM sys.dm_db_xtp_memory_consumers
WHERE object_id = object_id('Sales.SpecialOfferProduct_inmem')
GO

-- add a column
ALTER TABLE Sales.SpecialOfferProduct_inmem
	ADD c1 INT NULL
GO 

-- verify memory utilization for Sales.SpecialOfferProduct_inmem after running an ALTER
--   notice that there are two memory consumers for the table data, 
--   and two consumers each for the indexes. The old version of the table is still in memory
--   and is awaiting garbage collection.
SELECT object_name(object_id), 
	object_id,
	xtp_object_id,
	memory_consumer_type_desc,
	memory_consumer_desc,
	allocated_bytes,
	used_bytes
FROM sys.dm_db_xtp_memory_consumers
WHERE object_id = object_id('Sales.SpecialOfferProduct_inmem')
GO

-- drop the new column
ALTER TABLE Sales.SpecialOfferProduct_inmem
	DROP COLUMN c1
GO


