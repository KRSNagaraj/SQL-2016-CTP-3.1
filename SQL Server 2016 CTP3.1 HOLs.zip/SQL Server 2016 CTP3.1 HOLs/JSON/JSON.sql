Use AdventureWorks2016CTP3
Go
--Lab1 Data into JSON Output
--1.1 Query the data in its relational format
SELECT H.SalesOrderNumber,H.OrderDate,D.UnitPrice,D.OrderQty
FROM Sales.SalesOrderHeader H
INNER JOIN Sales.SalesOrderDetail D ON H.SalesOrderID=D.SalesOrderID
Go

--1.2 Now return the output as JSON
SELECT Top 10 H.SalesOrderNumber,H.OrderDate,D.UnitPrice,D.OrderQty
FROM Sales.SalesOrderHeader H
INNER JOIN Sales.SalesOrderDetail D ON H.SalesOrderID=D.SalesOrderID
FOR JSON AUTO
Go

--1.3 Explore JSON data structure by looking couple of records
SELECT H.SalesOrderNumber,H.OrderDate,D.UnitPrice,D.OrderQty
FROM Sales.SalesOrderHeader H
INNER JOIN Sales.SalesOrderDetail D ON H.SalesOrderID=D.SalesOrderID
WHERE H.SalesOrderID IN (43660,43669)
FOR JSON AUTO
Go
-- 1.4 Add a root key to JSON output
SELECT H.SalesOrderNumber,H.OrderDate,D.UnitPrice,D.OrderQty
FROM Sales.SalesOrderHeader H
INNER JOIN Sales.SalesOrderDetail D ON H.SalesOrderID=D.SalesOrderID
WHERE H.SalesOrderID IN (43660,43669)
FOR JSON AUTO, ROOT('SalesOrder')
Go

--Lab 2 Using FOR JSON PATH and other control structures
--2.1 start with a regular query for product information
SELECT TOP 7 M.ProductModelID, M.Name AS [ProductModel.Name], 
ProductID, P.Name AS [Product.Name], ProductNumber, MakeFlag,
FinishedGoodsFlag, Color, Size, SafetyStockLevel, ReorderPoint, SellStartDate
FROM Production.Product P
INNER JOIN Production.ProductModel M ON P.ProductModelID = M.ProductModelID
Go

--2.2 Modify JSON structure with FOR JSON PATH
SELECT TOP 7 M.ProductModelID, M.Name AS [ProductModel.Name], 
ProductID, P.Name AS [Product.Name], ProductNumber, MakeFlag,
FinishedGoodsFlag, Color, Size, SafetyStockLevel, ReorderPoint, SellStartDate
FROM Production.Product P
INNER JOIN Production.ProductModel M ON P.ProductModelID = M.ProductModelID
FOR JSON PATH
Go

--2.3 JSON result set where there are NULLs value for Size.  Notice that the Size attribute is not displayed
SELECT M.ProductModelID, M.Name AS [ProductModel.Name], 
ProductID, P.Name AS [Product.Name], Size
FROM Production.Product P
INNER JOIN Production.ProductModel M ON P.ProductModelID = M.ProductModelID
WHERE M.ProductModelID = 33
FOR JSON PATH

--2.4 Add INCLUDE_NULL_VALUES to the FOR JSON PATH.  Note that the Size attribute is returned.
SELECT M.ProductModelID, M.Name AS [ProductModel.Name], 
ProductID, P.Name AS [Product.Name], Size
FROM Production.Product P
INNER JOIN Production.ProductModel M ON P.ProductModelID = M.ProductModelID
WHERE M.ProductModelID = 33
FOR JSON PATH, INCLUDE_NULL_VALUES
Go

--2.5 Alternate JSON structure with nested queries
SELECT M.ProductModelID, M.Name AS [ProductModel.Name], 
	(SELECT ProductID, P.Name AS [Product.Name], Size
	 FROM Production.Product P
	 WHERE P.ProductModelID = M.ProductModelID
	 FOR JSON PATH) AS P 
FROM Production.ProductModel M 
WHERE M.ProductModelID = 33
FOR JSON PATH


-- Lab 3 For Export relational data from SQL Server to a JSON file
SELECT TOP 5 M.ProductModelID, M.Name AS [ProductModel.Name], 
ProductID, P.Name AS [Product.Name], ProductNumber, MakeFlag,
FinishedGoodsFlag, Color, Size, SafetyStockLevel, ReorderPoint, SellStartDate
FROM Production.Product P
INNER JOIN Production.ProductModel M ON P.ProductModelID = M.ProductModelID
FOR JSON PATH, ROOT ('ProductModel')




