EXEC sp_configure 'remote data archive', '1';
RECONFIGURE;
GO
