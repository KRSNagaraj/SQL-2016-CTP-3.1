-- Row-Level Security Hands-On Lab

-- Lab 1: RLS security where users connect directly to the database
USE db_rls_demo_hospital
GO

-- 1.1 Explore the DB before RLS is implemented
-- You can see the patients
SELECT * FROM [patients];
GO

-- View the database role members
SELECT user_name(role_principal_id) Role, user_name(member_principal_id) Member
FROM sys.database_role_members
GO

-- View the existing users, roles, and the wing they are assigned to
SELECT s.empId, s.[role], e.name, user_name(e.databasePrincipalId) as [SqlUserName], 
s.wing, s.startTime, s.endTime 
FROM staffDuties s 
INNER JOIN employees e ON (e.empId = s.empId) 
ORDER BY empId;
GO


-- 1.2 Create the RLS predicate function: First we'll use a simple filter
-- Create a new schema
CREATE SCHEMA [Security]
GO

-- Create the RLS predicate function
CREATE FUNCTION [Security].fn_securitypredicate(@wing int, @startTime datetime, @endTime datetime)
RETURNS TABLE 
WITH SCHEMABINDING
AS
    RETURN SELECT 1 as [fn_securitypredicate_result] 
	FROM dbo.StaffDuties d 
	INNER JOIN dbo.Employees e ON (d.EmpId = e.EmpId) 
    WHERE e.databasePrincipalId = database_principal_id() 
	AND @wing = d.Wing
	AND ((d.endTime >= @startTime) 
		AND 
		((d.startTime <= isnull(@endTime, getdate()))))
GO


-- 1.3 Create a security policy to bind the predicate function to the patients table
CREATE SECURITY POLICY [Security].[PatientsSecurity] 
ADD FILTER PREDICATE [Security].[fn_securitypredicate]([wing], [startTime], [endTime]) 
ON [dbo].[patients]
GO

-- Verify that you as DBA can no longer see the patients
SELECT * FROM dbo.[patients];

-- Other users can see some patients, depending on their role and the hospital wing to which they are assigned
EXECUTE ('SELECT * FROM [patients];') AS USER = 'CodyR' --admin
GO
EXECUTE ('SELECT * FROM [patients];') AS USER = 'NightingaleF' --nurse
GO
EXECUTE ('SELECT * FROM [patients];') AS USER = 'AllenM' --nurse 
GO
EXECUTE ('SELECT * FROM [patients];') AS USER = 'CharcotJ' --doctor 
GO
-- 1.4 Modify the security policy with a new, more complex predicate function
CREATE FUNCTION [Security].fn_securitypredicate2(@wing int, @startTime datetime, @endTime datetime)
RETURNS TABLE 
WITH SCHEMABINDING
AS
    RETURN SELECT 1 as [fn_securitypredicate_result] 
	FROM dbo.StaffDuties d 
	INNER JOIN dbo.Employees e ON (d.EmpId = e.EmpId) 
    WHERE (e.databasePrincipalId = database_principal_id() 
	AND (   -- nurses & doctors can see the data for the wings they were working on...
			( (is_member('nurse') = 1  OR is_member('doctor') = 1 ) AND @wing = d.Wing)
			OR
			-- doctors can also see the data from the "emergency" wing
			( is_member('doctor') = 1 AND @wing = 3)
		)
		AND ( -- during the time of the day they were on duty
			(d.endTime >= @startTime) 
			AND 
			((d.startTime <= isnull(@endTime, getdate())))
		)
	)
	OR (-- RLS won't apply to 'administrator' members
		-- Note: This group could also be a domain security group instead of a SQL role
		is_member('administrator') = 1
	)
GO

-- Modify the policy to bind the new predicate function to patients (replacing the old filter predicate)
ALTER SECURITY POLICY [Security].[PatientsSecurity] 
	ALTER FILTER PREDICATE [Security].[fn_securitypredicate2](wing, startTime, endTime) 
	ON dbo.[patients]
GO

-- Verify that the new policy works as expected
EXECUTE ('SELECT * FROM [patients];') AS USER = 'CodyR' --admin
GO
EXECUTE ('SELECT * FROM [patients];') AS USER = 'NightingaleF' --nurse
GO
EXECUTE ('SELECT * FROM [patients];') AS USER = 'AllenM' --nurse 
GO
EXECUTE ('SELECT * FROM [patients];') AS USER = 'CharcotJ' --doctor 
GO


-- 1.5 Finally, let's look at the showplan to see how the query optimizer applies RLS
-- When policy is disabled, the filter predicate isn't applied (just an index scan, as normal)
ALTER SECURITY POLICY [Security].PatientsSecurity WITH (STATE = OFF)
GO
SET SHOWPLAN_ALL ON
GO
SELECT * FROM patients
GO
SET SHOWPLAN_ALL OFF
GO

-- When policy is enabled, the query optimizer applies the filter predicate
ALTER SECURITY POLICY [Security].PatientsSecurity WITH (STATE = ON)
GO
SET SHOWPLAN_ALL ON
GO
SELECT * FROM patients
GO
SET SHOWPLAN_ALL OFF
GO



-- Lab 2:  Middle-Tier RLS Applications with CONTEXT_INFO 
-- (NOTE: This lab uses a different database than the first part)
USE db_rls_demo_midtierapp
GO

-- 2.1 Explore the DB and add a new application user
-- View the existing Sales data
SELECT * FROM Sales
GO

-- Create an index on the column we will use for the filter in order to improve performance
CREATE CLUSTERED INDEX IX_Sales_TenantId
    ON dbo.Sales(TenantId) 
GO

-- Create the shared application user, without login to simplify the demo
CREATE USER AppUser WITHOUT LOGIN 
GRANT SELECT ON Sales TO AppUser
GO


-- 2.2 Create the stored procedure that will be used with RLS
-- Create a separate schema for our RLS Security Policies and filter predicate functions
CREATE SCHEMA [Security]
GO

-- Create a stored procedure that our middle-tier application can use to set CONTEXT_INFO to a TenantId
CREATE PROCEDURE [Security].sp_setContextInfoAsTenantId(@TenantId int)
AS
	SET CONTEXT_INFO @TenantId -- note: cannot be null
GO

-- Set exec rights on the proc to the AppUser user
GRANT EXECUTE ON [Security].sp_setContextInfoAsTenantId TO AppUser
GO

-- 2.3 Create an inline table-valued function (our filter predicate) that will only return rows where 
-- @TenantId = CONTEXT_INFO. If CONTEXT_INFO has not been set, we return no rows by default.
-- Note that we do all type conversions on CONTEXT_INFO to maximize performance.
CREATE FUNCTION [Security].fn_tenantAccessPredicate(@TenantId int)
RETURNS TABLE
WITH SCHEMABINDING
AS
	RETURN SELECT 1 AS fn_accessResult 
	WHERE DATABASE_PRINCIPAL_ID() = DATABASE_PRINCIPAL_ID ('AppUser') -- the shared application login
	AND CONVERT(int, CONVERT(varbinary(4), CONTEXT_INFO())) = @TenantId -- @TenantId (int) is 4 bytes
GO


-- 2.4 Create and enable a Security Policy that binds the predicate function to the Sales table and verify that it works
-- First create and apply the policy
CREATE SECURITY POLICY [Security].tenantAccessPolicy
	ADD FILTER PREDICATE [Security].fn_tenantAccessPredicate(TenantId) ON dbo.Sales
GO

-- Since we haven't set the CONTEXT_INFO to anything, we cannot see any rows by default
SELECT * FROM Sales -- no rows
GO

-- Impersonate the application for demo purposes
EXECUTE AS USER = 'AppUser'
GO

-- After the app sets CONTEXT_INFO, rows are filtered based on the TenantId
EXECUTE [Security].sp_setContextInfoAsTenantId 1
GO
SELECT * FROM Sales -- only Book001
GO

-- Try it with TenantId set to 2
EXECUTE [Security].sp_setContextInfoAsTenantId 2
GO
SELECT * FROM Sales -- only Movie001 and Movie002
GO

REVERT
GO
