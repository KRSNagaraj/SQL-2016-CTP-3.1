-- If you haven't already set your current database, run these 2 lines
USE AdventureworksDW2016CTP3
GO

-- Verify the size of the table
SELECT COUNT(*) FROM FactResellerSalesXL_CCI
GO

-- Create a foreign key
-- 1.
ALTER TABLE [dbo].[FactResellerSalesXL_CCI]  WITH CHECK 
ADD CONSTRAINT [FK_FactResellerSalesXLCCI_DimEmployee] FOREIGN KEY([EmployeeKey])
REFERENCES [dbo].[DimEmployee] ([EmployeeKey])
GO
ALTER TABLE [dbo].[FactResellerSalesXL_CCI] 
CHECK CONSTRAINT [FK_FactResellerSalesXLCCI_DimEmployee]
GO

-- 2. verify that foreign key enforces ref. integrity: This will produce an error
DECLARE @nonexistentEmployeeKey int
SELECT @nonexistentEmployeeKey = MAX(EmployeeKey)+1 FROM [DimEmployee]
INSERT INTO FactResellerSalesXL_CCI
([ProductKey],[OrderDateKey],[DueDateKey],[ShipDateKey],
 [ResellerKey],[EmployeeKey],[PromotionKey],[CurrencyKey],
 [SalesTerritoryKey],[SalesOrderNumber],[SalesOrderLineNumber])
VALUES(310,20140101,20140104,20140102,150,@nonexistentEmployeeKey,
1,100,10,'S0101',1)
GO


-- Create an additional non-clustered index on the table
--1 Run a simple query without the additional index
SET STATISTICS XML ON
SET STATISTICS IO ON
GO
SELECT b.ProductKey, OrderDateKey, SalesTerritoryKey, EmployeeKey
FROM FactResellerSalesXL_CCI a 
INNER JOIN DimProduct b ON a.ProductKey = b.ProductKey
WHERE OrderDateKey BETWEEN 20080201 AND 20090801
AND b.ProductKey = 310
GO

-- 3 Create a non-clustered index. 
CREATE NONCLUSTERED INDEX idxProductOrderDate
ON dbo.FactResellerSalesXL_CCI (ProductKey, OrderDateKey)
INCLUDE (EmployeeKey, SalesTerritoryKey)
GO

-- 4 re-run the query now that there is an index
SET STATISTICS XML ON
SET STATISTICS IO ON
GO
SELECT b.ProductKey, OrderDateKey, SalesTerritoryKey, EmployeeKey
FROM FactResellerSalesXL_CCI a 
INNER JOIN DimProduct b ON a.ProductKey = b.ProductKey
WHERE OrderDateKey BETWEEN 20080201 AND 20090801
AND b.ProductKey = 310
GO
SET STATISTICS XML OFF
SET STATISTICS IO OFF

-- 5 Run a simple query with a predicate
SET STATISTICS XML ON
SET STATISTICS IO ON
GO
SELECT COUNT(*)
FROM FactResellerSalesXL_CCI 
WHERE OrderDateKey BETWEEN 20060101 AND 20070101
GO
SET STATISTICS XML OFF
SET STATISTICS IO OFF
