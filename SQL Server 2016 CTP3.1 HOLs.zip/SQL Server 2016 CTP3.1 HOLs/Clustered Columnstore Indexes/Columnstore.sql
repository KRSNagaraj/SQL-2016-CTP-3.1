-- 4 Look at the row groups information
SELECT *
FROM sys.column_store_row_groups
WHERE object_id = OBJECT_ID('SalesOrder')
GO

-- 5 Compare performance on a simple select with columnstore index (here) to the hash index (next statement)
SET STATISTICS TIME ON
SET STATISTICS IO ON

SELECT COUNT(*) FROM SalesORder
GO

-- using the hash index
SET STATISTICS TIME ON
SET STATISTICS IO ON
GO
SELECT COUNT(*) FROM SalesOrder WITH(INDEX = PK_SalesOrderId)
GO

-- 9. Compare performance on an aggregate select with columnstore index (here) to the hash index (next statement)
SET STATISTICS TIME ON
SET STATISTICS IO ON
GO
SELECT AVG (CONVERT(bigint, SalesAmount)) FROM SalesOrder
GO

-- 10. using the hash index
SET STATISTICS TIME ON
SET STATISTICS IO ON
GO
SELECT AVG (CONVERT(bigint, SalesAmount)) FROM SalesOrder WITH(INDEX = PK_SalesOrderID)
GO

-- 11. Compare performance with a natively compiled stored proc (here) to the hash index (next statement)
SET STATISTICS TIME ON
SET STATISTICS IO ON
GO
IF OBJECT_ID('Hk_GetAvgSalesAmt') IS NOT NULL
DROP PROCEDURE Hk_GetAvgSalesAmt
GO
CREATE PROCEDURE Hk_GetAvgSalesAmt WITH SCHEMABINDING, NATIVE_COMPILATION, EXECUTE AS OWNER
AS
BEGIN ATOMIC WITH(TRANSACTION ISOLATION LEVEL = SNAPSHOT, LANGUAGE = N'ENGLISH')
	SELECT AVG (CONVERT(bigint, SalesAmount)) FROM dbo.SalesOrder
END
GO
-- Execute
EXEC Hk_GetAvgSalesAmt
GO

-- 13 Insert performance for adding new data
SET STATISTICS TIME ON
SET STATISTICS IO ON
GO
SELECT AVG ( SalesAmount) FROM SalesOrder --average before insertion
GO
SELECT COUNT(*) FROM SalesOrder WITH (INDEX=SalesOrder_cci)
GO
EXEC Insert10K_Rows_in_SalesOrder
GO

-- 16 Verify new rows are not in compressed rowgroups
SELECT *
FROM sys.column_store_row_groups
WHERE object_id = OBJECT_ID('SalesOrder')
GO