-- Create a workgroup using the resource pool we just created
CREATE WORKLOAD GROUP dbagroup
WITH (
    IMPORTANCE = MEDIUM, -- relative importance compared to other workgroups
    REQUEST_MAX_MEMORY_GRANT_PERCENT = 50, -- how much memory a single process can request from the pool
     REQUEST_MAX_CPU_TIME_SEC = 0, -- how long a single request can take without generating a CPU Threshold Exceeded event , 0 means unlimited       
      MAX_DOP = 0, -- max degree of parallelism allowed
      GROUP_MAX_REQUESTS = 0 -- num simultaneous events allowed, 0 means unlimited
)
USING dbapool
;
GO
-- update resource governor to changes
ALTER RESOURCE GOVERNOR RECONFIGURE;
GO


