-- Create a new resource pool explicitly stating all values
-- As all values being given are defaults, this could alternatively be done
-- as CREATE RESOURCE POOL dbapool;
CREATE RESOURCE POOL dbapool
WITH
     ( MIN_CPU_PERCENT = 0, -- how much must be assigned to this pool
     MAX_CPU_PERCENT = 100, -- how much would be assigned if possible (note, can be exceeded if no contention for resources)
     CAP_CPU_PERCENT = 100, -- cannot-be-exceeded maximum, useful for predictable billing
    AFFINITY SCHEDULER = AUTO,
    MIN_MEMORY_PERCENT = 0, -- memory allocated to this pool that cannot be shared
    MAX_MEMORY_PERCENT = 100, -- percentage total server memory which is allowed to be used by this pool
    MIN_IOPS_PER_VOLUME = 0, -- minimum number of I/O operations per second per disk volume to reserve
    MAX_IOPS_PER_VOLUME = 2147483647 -- maximum. Note, this is the max allowed value for this property.
);


