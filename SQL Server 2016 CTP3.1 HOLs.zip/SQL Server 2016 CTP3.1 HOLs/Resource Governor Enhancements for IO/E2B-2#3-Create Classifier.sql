-- make a function returning the workgroup name for the session to be allocated to
-- allocates new sessions to dbapool if dba in login name
USE Master
GO
CREATE FUNCTION fx_DBAClassifier()
RETURNS sysname
WITH SCHEMABINDING
AS
BEGIN

	DECLARE @wg sysname
IF
	SUSER_NAME() LIKE '%dba%'
		SET @wg = 'dbagroup'
	ELSE SET @wg = 'default'
	RETURN @wg
END;
GO

-- tell the resource governor to use the function
ALTER RESOURCE GOVERNOR with (CLASSIFIER_FUNCTION = dbo.fx_DBAClassifier);
-- restart the resource governor
ALTER RESOURCE GOVERNOR RECONFIGURE;
GO
