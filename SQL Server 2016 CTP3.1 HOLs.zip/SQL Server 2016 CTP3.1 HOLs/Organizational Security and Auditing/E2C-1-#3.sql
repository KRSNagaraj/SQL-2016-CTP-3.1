USE AdventureWorks2016CTP3
GO
SELECT TOP 10 [BusinessEntityID]
      ,[RateChangeDate]
      ,[Rate]
      ,[PayFrequency]
,[ModifiedDate]
FROM [AdventureWorks2016CTP3].[HumanResources].[EmployeePayHistory]
GO