﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace QueryStoreSimpleDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            RunRegressionDemo();

        }

        private static void RunRegressionDemo()
        {
            SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();

            sb.DataSource = "MHLIVESQL0717"; 
            sb.InitialCatalog = "QueryStoreDemo";
            sb.IntegratedSecurity = true;


            Console.WriteLine("-----------------------------------------------------------");
            Console.WriteLine();
            Console.WriteLine("Real workload simulation (PSP)\n\nMultiple execution plans are being generated on stored procedure recompile,\nbased on randomly supplied parameter value.\nUnderlying dataset has non-uniform parameter value distribution.");
            Console.WriteLine();
            Console.WriteLine("-----------------------------------------------------------");
            Console.WriteLine("\nPress ENTER to start...");
            Console.WriteLine();
            Console.ReadLine();


            //RunTestOne(sb);
            RunTestOverview(sb);

            Console.WriteLine("Execution finished.");
            Console.WriteLine();
            
        }

        private static void RunTestOverview(SqlConnectionStringBuilder sb)
        {
            using (SqlConnection conn = new SqlConnection(sb.ToString()))
            {
                Console.WriteLine("Attempting to open connection");
                Console.WriteLine(sb.ToString());
                conn.Open();                

                SqlCommand init = conn.CreateCommand();
                init.CommandText = "ALTER DATABASE CURRENT SET QUERY_STORE CLEAR;";
                init.ExecuteNonQuery();

                init.ExecuteNonQuery();


                //SqlCommand initProd = prodConn.CreateCommand();
                //initProd.CommandText = "ALTER DATABASE QueryStoreTest SET QUERY_STORE CLEAR;";
                //initProd.ExecuteNonQuery();

                Console.WriteLine("Query Store data cleared!");


                SqlCommand comm = conn.CreateCommand();
                //SqlCommand prodComm = prodConn.CreateCommand();

                comm.CommandText = "select top 10000 * from t1 where  c1=@p1 and c2=@p2"; //"sp_dummyworkload";

                //prodComm.CommandText = comm.CommandText;
                //comm.CommandType = System.Data.CommandType.StoredProcedure;
                comm.Parameters.Add("@p1", System.Data.SqlDbType.Int);
                comm.Parameters.Add("@p2", System.Data.SqlDbType.Int);





                SqlCommand freeCacheComm = conn.CreateCommand();
                freeCacheComm.CommandText = "dbcc freeproccache;";


                int p1, p2;
                Random rand = new Random();
                //Stopwatch sw = new Stopwatch();

                for (int i = 1; i < 100000; i++)
                {
                    comm.Connection = conn;

                    if (i % 100 == 0)
                    {
                        p1 = rand.Next(10000);
                        p2 = p1;

                        comm.Parameters["@p1"].Value = p1;
                        comm.Parameters["@p2"].Value = p2;
                    }
                    else
                    {
                        comm.Parameters["@p1"].Value = 1;
                        comm.Parameters["@p2"].Value = 1;
                    }

                    SqlDataReader r = comm.ExecuteReader();


                    while (r.Read()) { }

                    r.Close();                   


                    Console.WriteLine("Completed {0} execution.", i);



                    //with 3% probability free proc cache
                    int p = rand.Next(100);
                    if (p < 3)
                    {
                        freeCacheComm.Connection = conn;
                        freeCacheComm.ExecuteNonQuery();


                        Console.WriteLine("Plan cache gets CLEARED!");

                        //and then with 1.5% generate plan with non-optimal parameter
                        if (p % 2 == 0)
                        {
                            comm.Parameters["@p1"].Value = 1;
                            comm.Parameters["@p2"].Value = 1;


                            Console.WriteLine("<Skewed parameter forced>!");
                        }
                        else
                        {
                            comm.Parameters["@p1"].Value = 105;
                            comm.Parameters["@p2"].Value = 105;

                        }

                        comm.Connection = conn;
                        comm.ExecuteNonQuery();
                      

                    }
                }
                conn.Close();
            }
        }

    }
}
